package abstractDemo;

public abstract class BaseDatabaseManager {
	public abstract void getData();
}
