package inheritance2;

public class EmployeeManager extends PersonManager {
	
	public void BestEmployee() {
		System.out.println("Ayın elemanı getirildi");
	}
}
