package inheritance2;

public class Customer extends Person {
	
	String email;
}

