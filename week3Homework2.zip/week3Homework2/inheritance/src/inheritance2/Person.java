package inheritance2;

public class Person {
	int id;
	String firstName;
	String lastName;
	int age;
}
