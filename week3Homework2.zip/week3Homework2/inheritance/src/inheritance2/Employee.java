package inheritance2;

public class Employee extends Person {
	
	double salary;
}