package inheritance2;

public class CustomerManager extends PersonManager {
	
}
