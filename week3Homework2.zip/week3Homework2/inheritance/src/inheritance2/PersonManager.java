package inheritance2;

public class PersonManager {
	public void List() {
		System.out.println("Müşteri listelendi");
	}
	public void Add() {
		System.out.println("Müşteri eklendi");
	}
}
