package interfaceDemo;

public interface IPayable {
	void pay();
}
