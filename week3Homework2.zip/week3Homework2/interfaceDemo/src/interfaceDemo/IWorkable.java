package interfaceDemo;

public interface IWorkable {
	void work();
}
