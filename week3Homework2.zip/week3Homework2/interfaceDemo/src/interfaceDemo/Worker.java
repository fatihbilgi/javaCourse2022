package interfaceDemo;

public class Worker implements IWorkable, IEatable, IPayable {

	@Override
	public void work() {
		
		
	}

	@Override
	public void eat() {
		
		
	}

	@Override
	public void pay() {
		
		
	}

}
