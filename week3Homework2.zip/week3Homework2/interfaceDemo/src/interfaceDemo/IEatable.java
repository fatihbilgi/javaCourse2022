package interfaceDemo;

public interface IEatable {
	void eat();

}
