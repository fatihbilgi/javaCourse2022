package interfaceDemo;

public interface IMaintable {
	void maintain();
}
