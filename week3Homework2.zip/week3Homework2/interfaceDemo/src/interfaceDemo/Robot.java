package interfaceDemo;

public class Robot implements IWorkable, IMaintable {

	@Override
	public void work() {
		
		
	}

	@Override
	public void maintain() {
		
		
	}

}
