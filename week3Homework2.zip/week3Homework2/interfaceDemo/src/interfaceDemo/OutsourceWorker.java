package interfaceDemo;

public class OutsourceWorker implements IWorkable {

	@Override
	public void work() {
		
		
	}

}
