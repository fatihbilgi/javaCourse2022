package inheritanceDemo2;

public class AskerKrediManager extends BaseKrediManager {

}
