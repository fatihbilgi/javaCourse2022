package inheritanceDemo2;

public class KrediUI {
	public void KrediHesapla(BaseKrediManager baseKrediManager) {
		baseKrediManager.Hesapla();
	}
}
