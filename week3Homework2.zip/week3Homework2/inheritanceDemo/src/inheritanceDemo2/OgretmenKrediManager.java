package inheritanceDemo2;

public class OgretmenKrediManager extends BaseKrediManager {

}
