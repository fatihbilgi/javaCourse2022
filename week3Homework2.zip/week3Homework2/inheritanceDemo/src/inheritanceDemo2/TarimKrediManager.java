package inheritanceDemo2;

public class TarimKrediManager extends BaseKrediManager {

}
