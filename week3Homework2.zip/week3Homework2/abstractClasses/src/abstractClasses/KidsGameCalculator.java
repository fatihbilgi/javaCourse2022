package abstractClasses;

public class KidsGameCalculator extends GameCalculator {
	@Override
	public void hesapla() {
		System.out.println("Puanınız: 100");
	}
}
