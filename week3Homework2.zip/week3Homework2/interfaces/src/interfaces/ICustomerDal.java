package interfaces;

public interface ICustomerDal {
	void Add();
}
