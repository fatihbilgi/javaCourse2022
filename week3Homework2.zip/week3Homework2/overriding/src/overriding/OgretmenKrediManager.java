package overriding;

public class OgretmenKrediManager extends BaseKrediManager {
}
