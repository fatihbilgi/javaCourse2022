package overriding;

public class TarimKrediManager extends BaseKrediManager{

}
